import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Movie } from '../model/Movie';
@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  baseUrl: string= "http://localhost:3000/movies";
  
  constructor(private http:HttpClient) { }
   getmovies()
   {
     return this.http.get<Movie[]>(this.baseUrl);
   }

  //get users by id
  getMoviesById(id:number)
  {
    return this.http.get<Movie>(this.baseUrl+"/"+id);
  }

  //create user
  createMovie(movie: Movie)
   {
    return this.http.post(this.baseUrl,movie);
   }
}


