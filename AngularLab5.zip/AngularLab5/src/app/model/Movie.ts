export class Movie
{   id:number
    name : string;
    rating: string;
    dgenre: string;
}